//gobal variables
var a = 0; //correct answer counter
var cA = "empty"; //correct answer
var i = 1; //location in the array of the current question and correct answer
var buttnMap = [1, 2, 3, 4]; //array to shuffle the buttons

//ask Dr. Kumar about this
var parentDirectory = "https://www.netstate.com/states/images/geography_"; //used for questions2 array of urls
let questions2 = new Array();
questions2 = ["alaska.gif", "california.gif", "delaware.gif", "florida.gif", "georgia.gif", 
				"hawaii.gif", "idaho.gif", "kentucky.gif", "louisiana.gif", "maryland.gif", 
				"newyork.gif", "oklahoma.gif", "pennsylvania.gif", "rhodeisland.gif", "southcarolina.gif", 
				"texas.gif", "utah.gif", "virginia.gif", "washington.gif", "wisconsin.gif"];
				
//possible questions in an array of images
let questions = new Array();
questions = ["https://www.netstate.com/states/images/geography_alaska.gif", 
				"https://www.netstate.com/states/images/geography_california.gif",
				"https://www.netstate.com/states/images/geography_delaware.gif", 
				"https://www.netstate.com/states/images/geography_florida.gif", 
				"https://www.netstate.com/states/images/geography_georgia.gif", 
				"https://www.netstate.com/states/images/geography_hawaii.gif", 
				"https://www.netstate.com/states/images/geography_idaho.gif", 
				"https://www.netstate.com/states/images/geography_kentucky.gif", 
				"https://www.netstate.com/states/images/geography_louisiana.gif", 
				"https://www.netstate.com/states/images/geography_maryland.gif", 
				"https://www.netstate.com/states/images/geography_newyork.gif", 
				"https://www.netstate.com/states/images/geography_oklahoma.gif", 
				"https://www.netstate.com/states/images/geography_pennsylvania.gif", 
				"https://www.netstate.com/states/images/geography_rhodeisland.gif", 
				"https://www.netstate.com/states/images/geography_southcarolina.gif", 
				"https://www.netstate.com/states/images/geography_texas.gif", 
				"https://www.netstate.com/states/images/geography_utah.gif", 
				"https://www.netstate.com/states/images/geography_virginia.gif", 
				"https://www.netstate.com/states/images/geography_washington.gif", 
				"https://www.netstate.com/states/images/geography_wisconsin.gif"];
				
//possible answers in an array of strings
let answers = new Array();
answers = ["Alaska", "California", "Delaware", "Florida", "Georgia",
			"Hawaii", "Idaho", "Kentucky", "Louisiana", "Maryland", 
			"New York", "Oklahoma", "Pennsylvania", "Rhode Island",	"South Carolina", 
			"Texas", "Utah", "Virginia", "Washington", "Wisconsin"];

/*****************************************************************/
//for testing purposes
let printArray = (questions2, answers, n)=>
{
    ans = '';
    for (let i = 0; i < n; i++)
    {
        ans += questions2[i] + " ";
    }
    console.log(ans);
	ans2 = '';
    for (let i = 0; i < n; i++)
    {
        ans2 += answers[i] + " ";
    }
    console.log(ans2);
}
/*****************************************************************/

//shuffle arrays
let randomize = (questions2, answers, n)=>
{
    for (let i = n - 1; i > 0; i--)
    {
		let j = Math.floor(Math.random() * (i + 1));

        [questions2[i], questions2[j]] = [questions2[j], questions2[i]];
		[answers[i], answers[j]] = [answers[j], answers[i]];
    }
}	
let n = questions.length;
randomize (questions2, answers, n);

/*****************************************************************/
printArray(questions2, answers, n); //for testing purposes
/*****************************************************************/


var correctBtnClicked = false;
function yellowSetup(){
	//Highlighting the correct answer after pressing "Correct Answer" button
	var CorrAnsBtn = document.getElementById("button5");
	CorrAnsBtn.onclick = function(){
		var CorrAns = document.getElementById("button" + buttnMap[0]);
		//changes css
		CorrAns.style.backgroundColor = 'yellow';
		CorrAns.style.fontWeight = 'bold';
		
		correctBtnClicked = true;
	}
}

function start()
{
	//displaying first question and answer options
	document.getElementById("picture").src = parentDirectory + questions2[0]; //ask Dr. Kumar if this is what he wants?
	loadAnswers(0);
	
	//using the bubbling technique
	const wrapper = document.getElementById("wrapper");			
	wrapper.addEventListener('click', (event) => {
		const isButton = event.target.nodeName === 'BUTTON';
		if (!isButton) {
			return;
		}
		//grabbing the contents of the selected button
		var guess = document.getElementById(event.target.id).innerHTML;
		//comparing guess with correct answer and adding to counter
		if(guess === cA){
			a++;
			document.getElementById("correctAnsCount").innerHTML = a;
			alert("Congratulations! You got the correct answer.");
		}
		else
		{
			alert("Sorry. Wrong answer.");
		}
	})
	
	//calls function for the "Correct Answer" button
	yellowSetup();
	
	//display next question after clicking the "Next" button
	var nextBtn = document.getElementById("button6");
	nextBtn.onclick = function(){
		//stops displaying next question after the array finishes
		if(i<=19){
			document.getElementById("picture").src = parentDirectory + questions2[i]; //ask Dr. Kumar about here as well
			
			//reverts yellowSetup() after the next button is clicked 
			var CorrAns = document.getElementById("button" + buttnMap[0]);
			if (correctBtnClicked){
				CorrAns.style.backgroundColor = '#f0f0f0';
				CorrAns.style.fontWeight = 'normal';
				correctBtnClicked = false;
			}
			
			//loads answer options each time a new question appears
			loadAnswers(i);
			
			//question # counter
			document.getElementById("questionCounter").innerHTML = i+1;
			i++;
		}
		else{
			//stops the user from trying to continue playing after all the questions have been cycled; ends the game
			alert("Thanks for Playing! \r\n Your Final Score is: " + a + "/20 \r\n Refresh the page to Play Again.");
		}
	}
}

function loadAnswers (index){
	//randomizing button order
	for (let i = 4 - 1; i > 0; i--)
	{
		let j = Math.floor(Math.random() * (i + 1));
		[buttnMap[i], buttnMap[j]] = [buttnMap[j], buttnMap[i]];
	}
	
	//create 3 random incorrect answers
	let random1 = Math.floor(Math.random() * answers.length);
	while(random1 == index){
		random1 = Math.floor(Math.random() * answers.length);
	}
	
	let random2 = Math.floor(Math.random() * answers.length);
	while(random2 == index || random2 == random1){
		random2 = Math.floor(Math.random() * answers.length);
	}
	
	let random3 = Math.floor(Math.random() * answers.length);
	while(random3 == index || random3 == random2 || random3 == random1){
		random3 = Math.floor(Math.random() * answers.length);
	}
	
	//initialize all button labels to "nothing"
	document.getElementById("button1").innerHTML = "nothing";
	document.getElementById("button2").innerHTML = "nothing";
	document.getElementById("button3").innerHTML = "nothing";
	document.getElementById("button4").innerHTML = "nothing";
	
	//setting variable to current correct answer
	cA = answers[index];
	
	//placing the possible answers into the randomized buttons
	document.getElementById("button" + buttnMap[0]).innerHTML = answers[index];
	document.getElementById("button" + buttnMap[1]).innerHTML = answers[random1];
	document.getElementById("button" + buttnMap[2]).innerHTML = answers[random2];
	document.getElementById("button" + buttnMap[3]).innerHTML = answers[random3];
}